test_admin_user = {
    "name": "Admin",
    "email": "admin@email.com",
    "username": "admin_username",
    "password": "admin_pwd",
    "terms_and_conditions_checked": True,
}

test_admin_user_2 = {
    "name": "Admin_2",
    "email": "admin2@email.com",
    "username": "admin2_username",
    "password": "admin2_pwd",
    "terms_and_conditions_checked": True,
}

test_admin_user_3 = {
    "name": "Admin_3",
    "email": "admin3@email.com",
    "username": "admin3_username",
    "password": "admin3_pwd",
    "terms_and_conditions_checked": True,
}


user1 = {
    "name": "User",
    "email": "user1@email.com",
    "username": "user1",
    "password": "user1_pwd",
    "terms_and_conditions_checked": True,
    "available_to_mentor": True,
    "need_mentoring": True,
}

user2 = {
    "name": "Userb",
    "email": "user2@email.com",
    "username": "user2",
    "password": "user2_pwd",
    "terms_and_conditions_checked": True,
}

user3 = {
    "name": "s_t-r$a/n'ge   name",
    "email": "user3@email.com",
    "username": "user3",
    "password": "user3_pwd",
    "terms_and_conditions_checked": True,
}

user4 = {
    "name": "user4@email.com",
    "email": "user4@email.com",
    "username": "user4",
    "password": "user4_pwd",
    "terms_and_conditions_checked": True,
}