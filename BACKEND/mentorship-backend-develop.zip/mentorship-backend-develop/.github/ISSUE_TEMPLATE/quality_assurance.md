---
name: Quality Assurance task
about: Provide a group of test cases for the some parts of the project.
---

## Description
This issue is to test all the test cases of features in the project.

## Test Cases
You can check the following document for test cases: 

[OPTIONAL] 

| Test Case     | Outcome |
| ------------- | ------------- |
| Example of test case | E.g.: Success or Error|

## Definition of Done
- [ ] At least one test case tested.
- [ ] Approval by 1 mentor.

## Estimation
[INSERT NUMBER HERE] hours

